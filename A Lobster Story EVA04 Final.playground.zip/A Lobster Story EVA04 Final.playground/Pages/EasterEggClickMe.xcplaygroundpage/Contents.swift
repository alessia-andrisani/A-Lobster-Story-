//: [page 2]
//: [page 1](@previous)

import SwiftUI
import PlaygroundSupport


struct SceneTwo: View {
    @State var image: String = "Lobster 1"
    @State var image1: String = "Lobster 2"
    @State var image2: String = "Lobster 3"
    @State var rotation: Bool = false
    @State var Count = 999
    
    
    var body: some View {
        NavigationView{
        ZStack {
            Image(uiImage: UIImage(named: image)!)
                .opacity(1)
            VStack {
                Button(action: {
                    
                    let timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
                        image = "Lobster \((Count%3)+1)"
                        print(image)
                        Count = Count-1
                    }

                    
                }) {
                    Text("Tap me daddy")
                }
                .padding(10)
                .foregroundColor(Color.red)
                .background(Color.gray)
                .cornerRadius(10)
                .position(x:200,y:350)
            }
            
        }
        .frame(width: 400,height: 600)
    }
    }
}

PlaygroundPage.current.setLiveView(SceneTwo())

//: [Next](@next)
