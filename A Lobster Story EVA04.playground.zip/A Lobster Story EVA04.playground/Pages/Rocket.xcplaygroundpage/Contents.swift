//: [Previous](@previous)

import SwiftUI
import PlaygroundSupport

struct RocketView: View {
    @State var repetition = true
    @State var assey:CGFloat = 500
    @State var salita=false
    var body: some View {
        ZStack{
            
            Image(uiImage: UIImage(named: "noncelafaccio.jpeg")!)
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
            Text("Tap on the ship to see magic").position(x: 430, y: 200).foregroundColor(.white)
            
            Image(uiImage: UIImage(named: "ship.png")!)
                .resizable()
                .frame(width: 150, height: 150)
                .scaledToFill()
                .position(x: 430, y: assey)
                .onTapGesture {
                    let timer = Timer.scheduledTimer(withTimeInterval: 0.01, repeats: repetition) { timer in
                        
                        if (assey != -80){
                            
                            assey = assey-1
                        }else{
                            salita=false
                            timer.invalidate()
                        }
                        
                        
                    }
                }
            
            
        }
        .frame(width:394, height:594)
        
        
    }
}

PlaygroundPage.current.setLiveView(RocketView())
//: [Next](@next)
