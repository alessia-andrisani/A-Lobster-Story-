//: [Previous](@previous)

import SwiftUI
import PlaygroundSupport
import AVFAudio


struct DarkView: View {
    @State var count = 0
    @State var axisX: Double = 300
    @State var axisY: Double = 400
    @State var dirnegx = false
    @State var dirnegy = false
    @State var appeared: Double = 0
    @State var pigimage = "Pig.png"
    @State var audiopig: AVAudioPlayer?

    var body: some View {
        ZStack {
            Circle()
                .frame(width: 250, height: 250)
                .position(x: 197,y:250)
                .foregroundColor(.white)
            
            VStack {
                
                
                Text("What the 🦀 is happening?")
                    .frame(width: 350, height: 100)
                    .font(.largeTitle)
                    .foregroundColor(.black)
                    .padding()
                    .position(x: 197,y:250)
                
            }.onAppear {
                startPig()
                                
                            }
            
            Image(uiImage: UIImage(named: pigimage)!)
                .resizable()
                .frame(width: 70, height: 70)
                .scaledToFill()
                .position(x: axisX,y: axisY)
            let timer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: false) { timer in
                
                count = count + 1
                if (count <= 2000) {
                    if (dirnegx == false){
                        axisX = axisX + 0.5
                        if (dirnegy == false) {
                            axisY = axisY + 1
                            if (axisY == 500){
                                dirnegy = true
                            }
                        }
                        else {
                            axisY = axisY - 1
                            if (axisY == 0){
                                dirnegy = false
                            }
                        }
                        if (axisX == 350){
                            dirnegx = true
                        }
                    }
                    else {
                        axisX = axisX - 0.5
                        if (dirnegy == false) {
                            axisY = axisY + 1
                            if (axisY == 580){
                                dirnegy = true
                            }
                        }
                        else {
                            axisY = axisY - 1
                            if (axisY == 0){
                                dirnegy = false
                            }
                        }
                        if (axisX == 20){
                            dirnegx = false
                        }
                    }
                }
            }
            
        }
        .frame(width: 394, height: 594)
        .background(Color.black)
        .opacity(appeared)
        .animation(Animation.easeInOut(duration: 2.0), value: appeared)
        .onAppear {self.appeared = 1.0}
        .onDisappear {self.appeared = 0.0}
    }
    
    func startPig(){
        if let audioURL = Bundle.main.url(forResource: "flyingpig", withExtension: "mp3"){
            do{
                try audiopig = AVAudioPlayer(contentsOf: audioURL)
                audiopig?.numberOfLoops=0
                audiopig?.prepareToPlay()
                audiopig?.play()
                audiopig?.setVolume(2, fadeDuration: 0)
            }catch{
                print("errore \(error)")
            }
            
        }else{
            print("no audio found")
        }
    }
    
}

PlaygroundPage.current.setLiveView(DarkView())

//: [Next](@next)
