//: [Previous](@previous)

import SwiftUI
import PlaygroundSupport
import AVFAudio

struct PosterView: View {
    @State var audiohome: AVAudioPlayer?

    var body: some View {
        ZStack {
            Image(uiImage: UIImage(named: "Poster Lobster.jpeg")!)
                .opacity(1)
                .ignoresSafeArea(edges: .top)
        }.onAppear {
            startaudio()
        }
    
        .frame(width: 394,height: 594)
    }
    
    func startaudio(){
        if let audioURL = Bundle.main.url(forResource: "startmusic", withExtension: "mp3"){
            do{
                try audiohome = AVAudioPlayer(contentsOf: audioURL)
                audiohome?.numberOfLoops=0
                audiohome?.prepareToPlay()
                audiohome?.play()
                audiohome?.setVolume(2, fadeDuration: 0)
            }catch{
                print("errore \(error)")
            }
            
        }else{
            print("no audio found")
        }
    }
}

PlaygroundPage.current.setLiveView(PosterView())

//: [Next](@next)
