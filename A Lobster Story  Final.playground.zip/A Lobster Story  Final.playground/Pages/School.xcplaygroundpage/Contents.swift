//: [Previous](@previous)
import SwiftUI
import PlaygroundSupport
import AVFAudio


struct SchoolView: View {
    @State var audiochalk: AVAudioPlayer?

    var body: some View {
                VStack {
                    ZStack{
                    Image(uiImage: UIImage(named: "aula.jpeg")!)
                        .resizable()
                        .frame(width: 400, height: 450)
                        .scaledToFill()
                        .ignoresSafeArea()
                        
                        Image(uiImage: UIImage(named: "Ginaaula.png")!)
                            .resizable()
                            .frame(width: 170, height: 110)
                            .position(x: 40, y: 260)
                        
                        Image(uiImage: UIImage(named: "Ginaaula.png")!)
                            .resizable()
                            .frame(width: 170, height: 110)
                            .position(x: 45, y: 200)
                        
                        
                  
                        
                            
                            Image(uiImage: UIImage(named: "Ginaaulaspecchio.png")!)
                                .resizable()
                                .frame(width: 170, height: 110)
                                .position(x: 330, y: 250)
                            
                            Image(uiImage: UIImage(named: "Ginaaulaspecchio.png")!)
                                .resizable()
                                .frame(width: 170, height: 110)
                                .position(x: 320, y: 195)
                            
                            
                            Image(uiImage: UIImage(named: "Ginaaulaspecchio.png")!)
                                .resizable()
                                .frame(width: 100, height: 70)
                                .position(x: 280, y: 165)
                            
                        Image(uiImage: UIImage(named: "Nasa.png")!)
                            .resizable()
                            .frame(width: 80, height: 60)
                            .position(x: 120, y: 95)
                        
                        Image(uiImage: UIImage(named: "Ginaaula.png")!)
                            .resizable()
                            .frame(width: 40, height: 30)
                            .position(x: 120, y: 120)
                        
                        Image(uiImage: UIImage(named: "poke.jpg")!)
                            .resizable()
                            .frame(width: 100, height: 80)
                            .position(x: 220, y: 220)
                        
                        Image(uiImage: UIImage(named: "oak.png")!)
                            .resizable()
                            .frame(width: 80, height: 200)
                            .position(x: 220, y: 150)
                       
                      
                    }
                  
                    Text("The moment had come: the door was opening and… what the scared lobster saw was nothing like what she had expected. In front of her there were many lobsters sitting at tiny tables and wearing a strange suit. Finally the man spoke and explained that she had been admitted to a special school. She was puzzled and looked closer to the badge on the man’s gown. It was saying:” **ASBL: Astronaut’s School for Brave Lobsters**”.")
                        .font(.system(size: 12))
                        .frame(width: 363, height: 113)
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 4).strokeBorder (lineWidth: 2))
                        .position(x: 197, y: 64)
                        
                        
                        

                        
                    
                }
                .frame(width: 394,height: 594).onAppear {
                    startChalk()
                }
    }
    
    func startChalk(){
        if let audioURL = Bundle.main.url(forResource: "chalk", withExtension: "wav"){
            do{
                try audiochalk = AVAudioPlayer(contentsOf: audioURL)
                audiochalk?.numberOfLoops=0
                audiochalk?.prepareToPlay()
                audiochalk?.play()
                audiochalk?.setVolume(2, fadeDuration: 0)
            }catch{
                print("errore \(error)")
            }
            
        }else{
            print("no audio found")
        }
    }
}



PlaygroundPage.current.setLiveView(SchoolView())

//: [Next](@next)
