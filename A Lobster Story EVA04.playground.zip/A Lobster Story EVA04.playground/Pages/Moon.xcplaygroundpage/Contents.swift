//: [Previous](@previous)
import SwiftUI
import PlaygroundSupport
import AVFAudio

struct SceneSeven: View {
    @State var rotation = false
    @State var audiocaramel: AVAudioPlayer?

    var body: some View {
                VStack {
                    ZStack{
                        
                    Image(uiImage: UIImage(named: "Luna.png")!)
                        .resizable()
                        .frame(width: 400, height: 450)
                        .scaledToFill()
                        .ignoresSafeArea().onAppear {
                            startCaramel()
                        }
                        
                        Image(uiImage: UIImage(named: "ship.png")!)
                            .resizable()
                            .frame(width: 400, height: 400)
                            .position(x: 350, y: 130)
                        Image(uiImage: UIImage(named: "flag.png")!)
                            .resizable()
                            .frame(width: 170, height: 110)
                            .position(x: 200, y: 210)
                        Image(uiImage: UIImage(named: "Ginaaula.png")!)
                            .resizable()
                            .frame(width: 170, height: 110)
                            .position(x: 130, y: 260)
                        Image(uiImage: UIImage(named: "Terra2.png")!)
                            .resizable()
                            .padding()
                            .rotationEffect(rotation ? .zero : Angle.degrees(360))
                            .animation(.linear(duration: 50).repeatForever(autoreverses: false), value: rotation)
                            .frame(width: 150, height: 150)
                            .position(x: 90, y: 80).onAppear(perform: {
                                rotation=true
                            })
                        
                       
                           
                            
                      
                    }
                  
                    let text: String="She felt relieved and happy because her destiny was much more joyful than she had expected. She would become an astronaut!\n\n “Life is unpredictable. You can never tell what life has in store for you” \n \t\t\t\t\t\t\t\t\t-Gina Clawstrong"
                    Text(text)
                        .font(.system(size: 12))
                        .frame(width: 363, height: 115)
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 4).strokeBorder (lineWidth: 2))
                        .position(x: 197, y: 65)
                        
                        

                        
                    
                }
                .frame(width: 394,height: 594)
    }
    
    func startCaramel(){
        if let audioURL = Bundle.main.url(forResource: "caramel", withExtension: "mp3"){
            do{
                try audiocaramel = AVAudioPlayer(contentsOf: audioURL)
                audiocaramel?.numberOfLoops=0
                audiocaramel?.prepareToPlay()
                audiocaramel?.play()
                audiocaramel?.setVolume(2, fadeDuration: 0)
            }catch{
                print("errore \(error)")
            }
            
        }else{
            print("no audio found")
        }
    }
}



PlaygroundPage.current.setLiveView(SceneSeven())

//: [Next](@next)
