//: [Previous](@previous)

import SwiftUI
import PlaygroundSupport
import AVFAudio


struct RestaurantView: View {
    @State var temp = "Once upon a time there was a lobster who lived in a fish tank in a famous restaurant. Her name was **Gina** and every day she feared the moment when her time of being eaten would come."
    @State var text1 = "Once upon a time there was a lobster who lived in a fish tank in a famous restaurant. Her name was **Gina** and every day she feared the moment when her time of being eaten would come."
    @State var text2 = "One day a strange man walked into the restaurant and asked to speak to the chef. Gina noticed that the man was pointing at her. Because of that, she thought her time had come to go to the kitchen and reach her very last tank."
    @State var image = "Chef 1.png"
    @State var count = 1
    @State var docount = 1
    @State var assex: Double = 320
    @State var assey: Double = 340
    @State var asseydoc: Double = 340
    @State var assexdoc: Double = 120
    @State var docimage = "Doc 1.png"
    @State var repetition = true
    
    @State var audiouomo1: AVAudioPlayer?
    @State var restaurant: AVAudioPlayer?
    var body: some View {
                VStack {
                    ZStack{
                    Image(uiImage: UIImage(named: "Restaurant scene.png")!)
                        .resizable()
                        .frame(width: 400, height: 450)
                        .scaledToFill()
                        .ignoresSafeArea().onAppear {
                            startrestaurant()
                            
                        }
                        
                        if (temp == text1){
                        Button (action: {
                            temp = text2
                               
                        }, label: {
                            Text("Next")
                                .padding(10)
                                .foregroundColor(Color.white)
                                .background(Color.blue)
                                .cornerRadius(5)
                                .position(x: 350, y: 410)
                        })
                        }
                        
                        if (temp == text2){
                            
                            Image(uiImage: UIImage(named: image)!)
                                .resizable()
                                .frame(width: 70, height: 200)
                                .scaledToFill()
                                .position(x: assex ,y: assey)
                                let timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: repetition) { timer in
                                    image = "Chef \((count)+1)"
                                    if (count != 4){
                                        startwalkingMan1()

                                        count = count+1
                                        assex = assex-5
                                        assey = assey-5
                                    }
                                    else {
                                    }
                                    
                            }
                            
                            Image(uiImage: UIImage(named: docimage)!)
                                .resizable()
                                .frame(width: 70, height: 200)
                                .scaledToFill()
                                .position(x: assexdoc ,y: asseydoc)
                                let timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: repetition) { timer in
                                    docimage = "Doc \((docount)+1)"
                                    if (docount != 4){
                                        docount = docount+1
                                        assexdoc = assexdoc + 5
                                        asseydoc = asseydoc - 5
                                    }
                                    else {
                                    }
                                    
                            }
                        }
                    }
                        
                    Text(temp)
                        
                        .font(.system(size: 15))
                        .frame(width: 364, height: 116)
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 4).strokeBorder (lineWidth: 2))
                        .position(x: 197, y: 61)
                                   
                }
                .frame(width: 394,height: 594)
    }
    
    func startwalkingMan1(){
        if let audioURL = Bundle.main.url(forResource: "footstep", withExtension: "wav"){
            do{
                try audiouomo1 = AVAudioPlayer(contentsOf: audioURL)
                audiouomo1?.numberOfLoops=0
                audiouomo1?.play()
                audiouomo1?.setVolume(5, fadeDuration: 0)
            }catch{
                print("errore \(error)")
            }
            
        }else{
            print("no audio found")
        }
    }
    
    
    
    func startrestaurant(){
        if let audioURL = Bundle.main.url(forResource: "restaurantcutaudio", withExtension: "m4a"){
            do{
                try restaurant = AVAudioPlayer(contentsOf: audioURL)
                restaurant?.numberOfLoops=0
                restaurant?.play()
                restaurant?.setVolume(1, fadeDuration: 0)
            }catch{
                print("errore \(error)")
            }
            
        }else{
            print("no audio found")
        }
    }
}

PlaygroundPage.current.setLiveView(RestaurantView())

//: [Next](@next)
