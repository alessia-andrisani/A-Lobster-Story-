import SwiftUI
import PlaygroundSupport
import AVFAudio

struct MainView: View {
    @State var audiohome: AVAudioPlayer?
    
    var body: some View {
        NavigationView {
            ZStack {
                Image(uiImage: UIImage(named: "Poster Lobster.jpeg")!)
                    .opacity(1)
                    .ignoresSafeArea(edges: .top).onAppear {
                        startaudio()
                    }.onDisappear {
                        audiohome?.stop()
                    }
                
                NavigationLink(destination: SceneTwo(), label: { Text("Start")
                        .frame(width: 100, height: 15)
                        .padding(15)
                        .foregroundColor(Color.white)
                        .background((Color.blue).opacity(0.5))
                        .cornerRadius(10)
                        .position(x:200,y:300)
                        
                    
                })
                
                
            }
        }
        .frame(width: 394,height: 594)
    }
    
    func startaudio(){
        if let audioURL = Bundle.main.url(forResource: "startmusic", withExtension: "mp3"){
            do{
                try audiohome = AVAudioPlayer(contentsOf: audioURL)
                audiohome?.numberOfLoops = .max
                audiohome?.prepareToPlay()
                audiohome?.play()
                audiohome?.setVolume(2, fadeDuration: 0)
            }catch{
                print("errore \(error)")
            }
            
        }else{
            print("no audio found")
        }
    }
}

struct SceneTwo: View {
    @State var temp = "Once upon a time there was a lobster who lived in a fish tank in a famous restaurant. Her name was Gina and every day she feared the moment when her time of being eaten would come."
    @State var text1 = "Once upon a time there was a lobster who lived in a fish tank in a famous restaurant. Her name was Gina and every day she feared the moment when her time of being eaten would come."
    @State var text2 = "One day a strange man walked into the restaurant and asked to speak to the chef. Gina noticed that that man was pointing his finger towards her. Because of that, she thought her time had come to go to the kitchen and reach her very last tank."
    @State var image = "Chef 1.png"
    @State var count = 1
    @State var docount = 1
    @State var assex: Double = 320
    @State var assey: Double = 290
    @State var asseydoc: Double = 290
    @State var assexdoc: Double = 120
    @State var docimage = "Doc 1.png"
    @State var repetition = true
    @State var audiouomo1: AVAudioPlayer?
    @State var restaurant: AVAudioPlayer?

    var body: some View {
        VStack {
            ZStack{
                Image(uiImage: UIImage(named: "Restaurant scene.png")!)
                    .resizable()
                    .frame(width: 400, height: 450)
                    .scaledToFill()
                    .ignoresSafeArea().onAppear {
                        startrestaurant()
                        
                    }.onDisappear {
                        restaurant?.stop()
                    }
                
                
                if (temp == text1){
                    Button (action: {
                        temp = text2
                        
                    }, label: {
                        Text("Next")
                            .padding(10)
                            .foregroundColor(Color.white)
                            .background(Color.blue)
                            .cornerRadius(5)
                            .position(x: 350, y: 360)
                    })
                }
                
                if (temp == text2){
                    
                    NavigationLink(destination: SceneThree(), label: { Text("Next")
                            .frame(width: 100, height: 15)
                            .padding(15)
                            .foregroundColor(Color.white)
                            .background((Color.blue))
                            .cornerRadius(10)
                            .position(x:200,y:420)
                        
                    })
                    
                    Image(uiImage: UIImage(named: image)!)
                        .resizable()
                        .frame(width: 70, height: 200)
                        .scaledToFill()
                        .position(x: assex ,y: assey)
                    let timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: false) { timer in
                        image = "Chef \((count)+1)"
                        if (count != 4){
                            startwalkingMan1()

                            count = count+1
                            assex = assex-5
                            assey = assey-5
                        }
                        else {
                        }
                        
                    }
                    
                    Image(uiImage: UIImage(named: docimage)!)
                        .resizable()
                        .frame(width: 70, height: 200)
                        .scaledToFill()
                        .position(x: assexdoc ,y: asseydoc)
                    let timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: false) { timer in
                        docimage = "Doc \((docount)+1)"
//                        startwalkingMan2()
                        if (docount != 4){
                            docount = docount+1
                            assexdoc = assexdoc + 5
                            asseydoc = asseydoc - 5
                        }
                        else {
                        }
                        
                    }
                }
            }
            
            Text(temp)
            
                .font(.system(size: 15))
                .frame(width: 364, height: 158)
                .padding()
                .background(RoundedRectangle(cornerRadius: 4).strokeBorder (lineWidth: 2))
                .position(x: 197, y: 29)
            
        }
        .frame(width: 394,height: 594)
    }
    
    func startwalkingMan1(){
        if let audioURL = Bundle.main.url(forResource: "footstep", withExtension: "wav"){
            do{
                try audiouomo1 = AVAudioPlayer(contentsOf: audioURL)
                audiouomo1?.numberOfLoops=0
                audiouomo1?.play()
                audiouomo1?.setVolume(5, fadeDuration: 0)
            }catch{
                print("errore \(error)")
            }
            
        }else{
            print("no audio found")
        }
    }
    
    
    
    func startrestaurant(){
        if let audioURL = Bundle.main.url(forResource: "restaurantcutaudio", withExtension: "m4a"){
            do{
                try restaurant = AVAudioPlayer(contentsOf: audioURL)
                restaurant?.numberOfLoops = .max
                restaurant?.play()
                restaurant?.setVolume(1, fadeDuration: 0)
            }catch{
                print("errore \(error)")
            }
            
        }else{
            print("no audio found")
        }
    }
    }



struct SceneThree: View {
    @State var repetition = true
    @State var asseylobster: Double = 280
    @State var assey: Double = 5
    @State var image:String = "ManoBasta.png"
    @State var salita=false
    @State var flag = true
    var body: some View {
        VStack {
            ZStack{
                Image(uiImage: UIImage(named: "Vasca.jpeg")!)
                    .resizable()
                    .frame(width: 400, height: 450)
                    .scaledToFill()
                    .ignoresSafeArea()
                
                Text("Tap on the hand").position(x: 80, y: 20).foregroundColor(.white)
                
                Image(uiImage: UIImage(named: "ManoBasta.png")!)
                    .resizable()
                    .frame(width: 150, height: 150)
                    .scaledToFill()
                    .position(x: 200, y: assey)
                    .onTapGesture {
                        if (flag == true){
                            flag = false
                        let timer = Timer.scheduledTimer(withTimeInterval: 0.01, repeats: repetition) { timer in
                            if(salita==false){
                                if (assey != 280){
                                    
                                    assey = assey+1
                                }else{
                                    salita=true
                                }
                                
                            }else{
                                if (assey != 5){
                                    asseylobster = asseylobster-1
                                    assey = assey-1
                                }else{
                                    salita=false
                                    timer.invalidate()
                                }
                            }
                        }
                            
                        }
                    }
                if (asseylobster == 5){
                    NavigationLink(destination: SceneFour(), label: { Text("Next")
                            .frame(width: 100, height: 15)
                            .padding(15)
                            .foregroundColor(Color.white)
                            .background((Color.blue))
                            .cornerRadius(10)
                            .position(x:200,y:430)
                        
                    })
                }
                
                
                Image(uiImage: UIImage(named: "Gina-2.png")!)
                    .resizable()
                    .frame(width: 170, height: 110)
                    .position(x: 200, y: asseylobster)
            }
            
            Text("Suddenly, the cook grabbed Gina and all became black.")
                .frame(width: 363, height: 148)
                .padding()
                .background(RoundedRectangle(cornerRadius: 4).strokeBorder (lineWidth: 2))
                .position(x: 197, y: 29)
            
            
            
            
        }
        .frame(width: 394,height: 594)
    }
}

struct SceneFour: View {
    @State var count = 0
    @State var axisX: Double = 300
    @State var axisY: Double = 400
    @State var dirnegx = false
    @State var dirnegy = false
    @State var appeared: Double = 0
    @State var pigimage = "Pig.png"
    @State var audiopig: AVAudioPlayer?

    var body: some View {
        ZStack {
            Circle()
                .frame(width: 250, height: 250)
                .position(x: 197,y:200)
                .foregroundColor(.white)
            
            VStack {
                
                
                Text("What the 🦀 is happening?")
                    .frame(width: 350, height: 100)
                    .font(.largeTitle)
                    .foregroundColor(.black)
                    .padding()
                    .position(x: 197,y:200)
                    .onDisappear {
                        audiopig?.stop()
                    }
                
            }.onAppear {
startPig()
                
            }
            
            Image(uiImage: UIImage(named: pigimage)!)
                .resizable()
                .frame(width: 70, height: 70)
                .scaledToFill()
                .position(x: axisX,y: axisY)
            let timer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: false) { timer in
                
                count = count + 1
                if (count <= 2000) {
                    if (dirnegx == false){
                        axisX = axisX + 0.5
                        if (dirnegy == false) {
                            axisY = axisY + 1
                            if (axisY == 500){
                                dirnegy = true
                            }
                        }
                        else {
                            axisY = axisY - 1
                            if (axisY == 0){
                                dirnegy = false
                            }
                        }
                        if (axisX == 380){
                            dirnegx = true
                        }
                    }
                    else {
                        axisX = axisX - 0.5
                        if (dirnegy == false) {
                            axisY = axisY + 1
                            if (axisY == 500){
                                dirnegy = true
                            }
                        }
                        else {
                            axisY = axisY - 1
                            if (axisY == 0){
                                dirnegy = false
                            }
                        }
                        if (axisX == 20){
                            dirnegx = false
                        }
                    }
                }
            }
            NavigationLink(destination: SceneFive(), label: { Text("Next")
                    .frame(width: 100, height: 15)
                    .padding(15)
                    .foregroundColor(Color.white)
                    .background((Color.blue))
                    .cornerRadius(10)
                    .position(x:200,y:450)
                
            })
            
        }
        .frame(width: 394, height: 594)
        .background(Color.black)
        .opacity(appeared)
        .animation(Animation.easeInOut(duration: 2.0), value: appeared)
        .onAppear {self.appeared = 1.0}
        .onDisappear {self.appeared = 0.0}
    }
    
    func startPig(){
        if let audioURL = Bundle.main.url(forResource: "flyingpig", withExtension: "mp3"){
            do{
                try audiopig = AVAudioPlayer(contentsOf: audioURL)
                audiopig?.numberOfLoops = .max
                audiopig?.prepareToPlay()
                audiopig?.play()
                audiopig?.setVolume(2, fadeDuration: 0)
            }catch{
                print("errore \(error)")
            }
            
        }else{
            print("no audio found")
        }
    }
    
    
}

struct SceneFive: View {
    @State var image: String = "ClosedDoor.png"
    @State var text1: String = "After a while Gina found herself in a strange room and she realized that she was no longer in the restaurant she knew so well. She was with the strange  man who was at the restaurant. He was now wearing a white gown and a badge with a strange blue and red logo."
    @State var text2: String = "The man grabbed Gina and started walking towards a closed door. Gina was terrified because that man reminded her of a butcher that sometimes came to the restaurant."
    //    variabile temporanea per cambio di valori in modo da conservare text1 e text2 senza sovrascriverli
    @State var temp: String = "After a while Gina found herself in a strange room and she realized that she was no longer in the restaurant she knew so well. She was with the strange  man who was at the restaurant. He was now wearing a white gown and a badge with a strange blue and red logo."
    @State var audiodoor: AVAudioPlayer?

    var body: some View {
        VStack {
            ZStack{
                
                Image(uiImage: UIImage(named: image)!)
                    .resizable()
                    .frame(width: 400, height: 450)
                    .scaledToFill()
                    .ignoresSafeArea()
                
                Image(uiImage: UIImage(named: "oak2.png")!)
                    .resizable()
                    .frame(width: 70, height: 200)
                    .scaledToFill()
                    .position(x: 200, y: 180)
                
                Image(uiImage: UIImage(named: "Nasa.png")!)
                    .resizable()
                    .frame(width: 15, height: 15)
                    .scaledToFill()
                    .position(x: 215, y: 165)
                
                
                
                Image(uiImage: UIImage(named: "Gina-2.png")!)
                    .resizable()
                    .frame(width: 170, height: 110)
                    .position(x: 200, y: 350)
                if (image == "ClosedDoor.png"){
                    Button (action: {
                        startOpenDoor()
                        image = "OpenDoor.png"
                        temp = text2
                        
                    }, label: {
                        Text("Open")
                            .padding(10)
                            .foregroundColor(Color.white)
                            .background(Color.blue)
                            .cornerRadius(5)
                            .position(x: 270, y: 100)
                    })
                }
                else {
                    
                    NavigationLink(destination: SceneSix(), label: { Text("Next")
                            .frame(width: 100, height: 12)
                            .padding(10)
                            .foregroundColor(Color.white)
                            .background((Color.blue))
                            .cornerRadius(10)
                            .position(x:200,y:420)
                    })
                }
                
            }
            
            
            Text(temp)
                .font(.system(size: 15))
                .frame(width: 363, height: 115)
                .padding()
                .background(RoundedRectangle(cornerRadius: 4).strokeBorder (lineWidth: 2))
                .position(x: 197, y: 15)
            
            
        }
        .frame(width: 394,height: 594)
    }
    // funzione per far partire l'audio
    func startOpenDoor(){
        if let audioURL = Bundle.main.url(forResource: "opendoor", withExtension: "wav"){
            do{
                try audiodoor = AVAudioPlayer(contentsOf: audioURL)
                audiodoor?.numberOfLoops=0
                audiodoor?.play()
                audiodoor?.setVolume(0.50, fadeDuration: 0)
            }catch{
                print("errore \(error)")
            }
            
        }else{
            print("no audio found")
        }
    }
}

struct SceneSix: View {
    @State var audiochalk: AVAudioPlayer?

    var body: some View {
        VStack {
            ZStack{
                Image(uiImage: UIImage(named: "aula.jpeg")!)
                    .resizable()
                    .frame(width: 400, height: 450)
                    .scaledToFill()
                    .ignoresSafeArea()
                
                Image(uiImage: UIImage(named: "Ginaaula.png")!)
                    .resizable()
                    .frame(width: 170, height: 110)
                    .position(x: 40, y: 210)
                
                Image(uiImage: UIImage(named: "Ginaaula.png")!)
                    .resizable()
                    .frame(width: 170, height: 110)
                    .position(x: 45, y: 150)
                
                
                
                
                
                Image(uiImage: UIImage(named: "Ginaaulaspecchio.png")!)
                    .resizable()
                    .frame(width: 170, height: 110)
                    .position(x: 330, y: 200)
                
                Image(uiImage: UIImage(named: "Ginaaulaspecchio.png")!)
                    .resizable()
                    .frame(width: 170, height: 110)
                    .position(x: 320, y: 145)
                
                
                Image(uiImage: UIImage(named: "Ginaaulaspecchio.png")!)
                    .resizable()
                    .frame(width: 100, height: 70)
                    .position(x: 280, y: 115)
                
                Image(uiImage: UIImage(named: "Nasa.png")!)
                    .resizable()
                    .frame(width: 80, height: 60)
                    .position(x: 120, y: 45)
                
                Image(uiImage: UIImage(named: "Ginaaula.png")!)
                    .resizable()
                    .frame(width: 40, height: 30)
                    .position(x: 120, y: 70)
                
                Image(uiImage: UIImage(named: "poke.jpg")!)
                    .resizable()
                    .frame(width: 100, height: 80)
                    .position(x: 220, y: 170)
                
                Image(uiImage: UIImage(named: "oak.png")!)
                    .resizable()
                    .frame(width: 80, height: 200)
                    .position(x: 220, y: 100)
                
                
            }
            
            Text("The moment had come: the door was opening and… what the scared lobster saw was nothing like what she had expected. In front of her there were many lobsters sitting at tiny tables and wearing a strange suit. Finally the man spoke and explained that she had been admitted to a special school. She was puzzled and looked closer to the badge on the man’s gown. It was saying:” **ASBL: Astronaut’s School for Brave Lobsters**”.")
                .font(.system(size: 12))
                .frame(width: 363, height: 115)
                .padding()
                .background(RoundedRectangle(cornerRadius: 4).strokeBorder (lineWidth: 2))
                .position(x: 197, y: 15)
            
            NavigationLink(destination: SceneSeven(), label: { Text("Next")
                    .frame(width: 70, height: 6)
                    .padding(6)
                    .foregroundColor(Color.white)
                    .background((Color.blue))
                    .cornerRadius(10)
                    .position(x:350,y:3)
            })
            
            
            
            
            
        }
        .frame(width: 394,height: 594)
        .onAppear {
            startChalk()
        }
        .onDisappear {
            audiochalk?.stop()
        }
    }
    
    func startChalk(){
        if let audioURL = Bundle.main.url(forResource: "chalk", withExtension: "wav"){
            do{
                try audiochalk = AVAudioPlayer(contentsOf: audioURL)
                audiochalk?.numberOfLoops = .max
                audiochalk?.prepareToPlay()
                audiochalk?.play()
                audiochalk?.setVolume(2, fadeDuration: 0)
            }catch{
                print("errore \(error)")
            }
            
        }else{
            print("no audio found")
        }
    }
}

struct SceneSeven: View {
    @State var repetition = true
    @State var assey:CGFloat = 500
    @State var salita=false
    @State var audiorocket: AVAudioPlayer?
    var body: some View {
        ZStack{
            
            Image(uiImage: UIImage(named: "noncelafaccio.jpeg")!)
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
            Text("Tap on the ship to see magic").position(x: 430, y: 200).foregroundColor(.white)
            
            Image(uiImage: UIImage(named: "ship.png")!)
                .resizable()
                .frame(width: 150, height: 150)
                .scaledToFill()
                .position(x: 430, y: assey)
                .onTapGesture {
                    startRocket()
                    let timer = Timer.scheduledTimer(withTimeInterval: 0.01, repeats: repetition) { timer in
                        
                        if (assey != -130){
                            assey = assey-1
                        }else{
                            salita=false
                            timer.invalidate()
                        }
                        
                        
                    }
                }
                .onDisappear {
                    audiorocket?.stop()
                }
            if (assey == -130) {
                Button(action: {
                        PlaygroundPage.current.setLiveView(SceneEight())
                }, label: { Text("Next")
                        .frame(width: 70, height: 15)
                        .padding(15)
                        .foregroundColor(Color.white)
                        .background((Color.blue))
                        .cornerRadius(10)
                        .position(x:430,y:450)
                })
            }
            
        }
        .frame(width:394, height:594)
        
    }
    
    // funzione per far partire l'audio
    func startRocket(){
        if let audioURL = Bundle.main.url(forResource: "rocketsound", withExtension: "wav"){
            do{
                try audiorocket = AVAudioPlayer(contentsOf: audioURL)
                audiorocket?.numberOfLoops=0
                audiorocket?.play()
                audiorocket?.setVolume(0.50, fadeDuration: 0)
            }catch{
                print("errore \(error)")
            }
            
        }else{
            print("no audio found")
        }
    }
    
}


struct SceneEight: View {
    @State var rotation = false
    @State var audiocaramel: AVAudioPlayer?

    var body: some View {
                VStack {
                    ZStack{
                        
                    Image(uiImage: UIImage(named: "Luna.png")!)
                        .resizable()
                        .frame(width: 400, height: 450)
                        .scaledToFill()
                        .ignoresSafeArea().onAppear {
                            startCaramel()
                        }
                        
                        Image(uiImage: UIImage(named: "ship.png")!)
                            .resizable()
                            .frame(width: 400, height: 400)
                            .position(x: 350, y: 130)
                        Image(uiImage: UIImage(named: "flag.png")!)
                            .resizable()
                            .frame(width: 170, height: 110)
                            .position(x: 200, y: 210)
                        Image(uiImage: UIImage(named: "Ginaaula.png")!)
                            .resizable()
                            .frame(width: 170, height: 110)
                            .position(x: 130, y: 260)
                        Image(uiImage: UIImage(named: "Terra2.png")!)
                            .resizable()
                            .padding()
                            .rotationEffect(rotation ? .zero : Angle.degrees(360))
                            .animation(.linear(duration: 80).repeatForever(autoreverses: false), value: rotation)
                            .frame(width: 150, height: 150)
                            .position(x: 90, y: 65)
                        
                       
                           
                            
                      
                    }
                    .onAppear(perform: {
                        rotation=true
                    })
                  
                    let text: String="She felt relieved and happy because her destiny was much more joyful than she had expected. She would become an astronaut!\n\n “Life is unpredictable. You can never tell what life has in store for you” \n \t\t\t\t\t\t\t\t\t-Gina Clawstrong"
                    Text(text)
                        .font(.system(size: 12))
                        .frame(width: 363, height: 115)
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 4).strokeBorder (lineWidth: 2))
                        .position(x: 197, y: 65)
                        
                        

                        
                    
                }
                .frame(width: 394,height: 594)
    }
    
    func startCaramel(){
        if let audioURL = Bundle.main.url(forResource: "caramel", withExtension: "mp3"){
            do{
                try audiocaramel = AVAudioPlayer(contentsOf: audioURL)
                audiocaramel?.numberOfLoops = .max
                audiocaramel?.prepareToPlay()
                audiocaramel?.play()
                audiocaramel?.setVolume(2, fadeDuration: 0)
            }catch{
                print("errore \(error)")
            }
            
        }else{
            print("no audio found")
        }
    }
}


PlaygroundPage.current.setLiveView(MainView())

