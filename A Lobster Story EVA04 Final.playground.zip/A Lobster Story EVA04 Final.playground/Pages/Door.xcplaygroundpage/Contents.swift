//: [Previous](@previous)

import SwiftUI
import PlaygroundSupport
import AVFAudio


struct DoorView: View {
    @State var image: String = "ClosedDoor.png"
    @State var text1: String = "After a while Gina found herself in a strange room and she realized that she was no longer in the restaurant she knew so well. She was with the strange  man who was at the restaurant. He was now wearing a white gown and a badge with a strange blue and red logo."
    @State var text2: String = "The man grabbed Gina and started walking towards a closed door. Gina was terrified because that man reminded her of a butcher that sometimes came to the restaurant."
//    variabile temporanea per cambio di valori in modo da conservare text1 e text2 senza sovrascriverli
    @State var temp: String = "After a while Gina found herself in a strange room and she realized that she was no longer in the restaurant she knew so well. She was with the strange  man who was at the restaurant. He was now wearing a white gown and a badge with a strange blue and red logo."
    @State var audiodoor: AVAudioPlayer?

    var body: some View {
                VStack {
                    ZStack{
                        
                    Image(uiImage: UIImage(named: image)!)
                        .resizable()
                        .frame(width: 400, height: 450)
                        .scaledToFill()
                        .ignoresSafeArea()
                        
                        Image(uiImage: UIImage(named: "oak2.png")!)
                            .resizable()
                            .frame(width: 70, height: 200)
                            .scaledToFill()
                            .position(x: 200, y: 180)
                        
                        Image(uiImage: UIImage(named: "Nasa.png")!)
                            .resizable()
                            .frame(width: 15, height: 15)
                            .scaledToFill()
                            .position(x: 215, y: 165)
                        
                        
                        
                        Image(uiImage: UIImage(named: "Gina-2.png")!)
                            .resizable()
                            .frame(width: 170, height: 110)
                            .position(x: 200, y: 400)
                        if (image == "ClosedDoor.png"){
                        Button (action: {
                            startOpenDoor()
                            image = "OpenDoor.png"
                            temp = text2
                            
                               
                        }, label: {
                            Text("Open")
                                .padding(10)
                                .foregroundColor(Color.white)
                                .background(Color.blue)
                                .cornerRadius(5)
                                .position(x: 270, y: 100)
                        })
                        }
                    }
                    
                    
                    Text(temp)
                        .font(.system(size: 15))
                        .frame(width: 363, height: 115)
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 4).strokeBorder (lineWidth: 2))
                        .position(x: 197, y: 65)
                        
                    
                }
                .frame(width: 394,height: 594)
    }
    // funzione per far partire l'audio
    func startOpenDoor(){
        if let audioURL = Bundle.main.url(forResource: "opendoor", withExtension: "wav"){
            do{
                try audiodoor = AVAudioPlayer(contentsOf: audioURL)
                audiodoor?.numberOfLoops=0
                audiodoor?.play()
                audiodoor?.setVolume(0.50, fadeDuration: 0)
            }catch{
                print("errore \(error)")
            }
            
        }else{
            print("no audio found")
        }
    }
}

PlaygroundPage.current.setLiveView(DoorView())


//: [Next](@next)
