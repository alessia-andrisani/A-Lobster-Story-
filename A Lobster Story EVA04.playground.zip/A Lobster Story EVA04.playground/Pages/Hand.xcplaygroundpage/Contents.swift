//: [Previous](@previous)

import SwiftUI
import PlaygroundSupport


struct HandView: View {
    @State var repetition = true
    @State var asseylobster:CGFloat = 330
    @State var assey:CGFloat = 55
    @State var image:String = "ManoBasta.png"
    @State var salita=false
    @State var flag = true
    var body: some View {
                VStack {
                    ZStack{
                    Image(uiImage: UIImage(named: "Vasca.jpeg")!)
                        .resizable()
                        .frame(width: 400, height: 450)
                        .scaledToFill()
                        .ignoresSafeArea()
                        
                        Text("Tap on the hand").position(x: 80, y: 20).foregroundColor(.white)
                        
                        Image(uiImage: UIImage(named: "ManoBasta.png")!)
                            .resizable()
                            .frame(width: 150, height: 150)
                            .position(x: 200, y: assey)
                            .onTapGesture {
                                if (flag == true){
                                    flag = false
                                let timer = Timer.scheduledTimer(withTimeInterval: 0.01, repeats: repetition) { timer in
                                    if(salita==false){
                                        if (assey != 330){

                                            assey = assey+1
                                        }else{
                                            salita=true
                                        }

                                    }else{
                                        if (assey != 55){
                                            asseylobster=asseylobster-1
                                            assey = assey-1
                                        }else{
                                            salita=false
                                            timer.invalidate()
                                        }
                                    }
                                    
                            }
                            }
                            }
                        
                        
                        Image(uiImage: UIImage(named: "Gina-2.png")!)
                            .resizable()
                            .frame(width: 170, height: 110)
                            .position(x: 200, y: asseylobster)
                    }
                    
                    Text("Suddenly, the cook grabbed Gina and all became black.")
                        .frame(width: 363, height: 148)
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 4).strokeBorder (lineWidth: 2))
                        .position(x: 197, y: 79)
                        

                        
                    
                }
                .frame(width: 394,height: 594)
    }
}

PlaygroundPage.current.setLiveView(HandView())

//: [Next](@next)
